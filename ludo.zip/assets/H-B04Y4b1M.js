import{o}from"./errorBoundaries-2t9vxQUe.js";const t=({c:r})=>o.jsx("span",{"aria-hidden":"true",children:r});export{t as H};
