const e=r=>o=>{console.error(`[${r}]`,o)};export{e as l};
